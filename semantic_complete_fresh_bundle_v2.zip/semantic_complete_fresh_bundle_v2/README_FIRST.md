# semantic 完整新打包 v2

这个包把目前还能直接读取到的内容重新聚合成一个新的下载包。

包含：
- 总体设计目录
- 第二步候选合成目录
- 第三步 / 第四步 / 第五步 / runner / 命名任务包 的 zip 文件副本

建议先看：
1. `00_overall_design/semantic_asset_build_mvp_implementation_design.md`
2. `01_step2_candidate_synthesis/semantic_asset_build_step2_candidate_synthesis.md`

然后再解压：
- `02_step3_scoring_recommendation.zip`
- `03_step4_review_and_evidence.zip`
- `04_step5_finalize_and_publish.zip`
- `05_runner_next_all.zip`
